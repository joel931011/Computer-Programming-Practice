/****************************************************************************
  FileName     [ bst.h ]
  PackageName  [ util ]
  Synopsis     [ Define binary search tree package ]
  Author       [ Chung-Yang (Ric) Huang ]
  Copyright    [ Copyleft(c) 2005-present LaDs(III), GIEE, NTU, Taiwan ]
****************************************************************************/

#ifndef BST_H
#define BST_H

#include <cassert>
#include <vector>
#include <stack>
#include <iostream>
using namespace std;

template <class T> 
class BSTree;

template <class T>
class BSTreeNode
{
   friend class BSTree<T>;
   friend class BSTree<T>::iterator;

   BSTreeNode(const T& d, BSTreeNode* l = nullptr, BSTreeNode* r = nullptr)
      : _data(d), _left(l), _right(r) {}

   T _data;
   BSTreeNode* _left;
   BSTreeNode* _right;
};


template <class T>
class BSTree {
public:
   BSTree(): _root(nullptr), _size(0) {}
   ~BSTree() { clear(); }
void sort() const {}  // BST 本身已排序，不需額外處理
void print() const {} // 只是為了相容於 adtTest 的呼叫，不需實作

   class iterator {
      friend class BSTree<T>;
   public:
      iterator(BSTreeNode<T>* n = nullptr): _node(n) {
         if (n) buildTrace(n);
      }

      const T& operator*() const { return _node->_data; }
      T& operator*() { return _node->_data; }

      iterator& operator++() {
         if (_node->_right) {
            _node = _node->_right;
            while (_node->_left) _node = _node->_left;
         } else {
            BSTreeNode<T>* succ = nullptr;
            BSTreeNode<T>* cur = _root;
            while (cur) {
               if (_node->_data < cur->_data) {
                  succ = cur;
                  cur = cur->_left;
               } else if (_node->_data > cur->_data) {
                  cur = cur->_right;
               } else break;
            }
            _node = succ;
         }
         return *this;
      }

      iterator operator++(int) { iterator tmp = *this; ++(*this); return tmp; }

      iterator& operator--() {
         if (!_node) {
            _node = _root;
            if (_node)
               while (_node->_right) _node = _node->_right;
         } else if (_node->_left) {
            _node = _node->_left;
            while (_node->_right) _node = _node->_right;
         } else {
            BSTreeNode<T>* pred = nullptr;
            BSTreeNode<T>* cur = _root;
            while (cur) {
               if (_node->_data > cur->_data) {
                  pred = cur;
                  cur = cur->_right;
               } else if (_node->_data < cur->_data) {
                  cur = cur->_left;
               } else break;
            }
            _node = pred;
         }
         return *this;
      }

      iterator operator--(int) { iterator tmp = *this; --(*this); return tmp; }

      bool operator==(const iterator& i) const { return _node == i._node; }
      bool operator!=(const iterator& i) const { return _node != i._node; }

   private:
      BSTreeNode<T>* _node;
      static BSTreeNode<T>* _root;
      void buildTrace(BSTreeNode<T>* n) { _root = n; }
   };

   iterator begin() const {
      BSTreeNode<T>* cur = _root;
      if (!cur) return end();
      while (cur->_left) cur = cur->_left;
      iterator it(cur); it.iterator::_root = _root; return it;
   }
   iterator end() const {
      iterator it(nullptr); it.iterator::_root = _root; return it;
   }

   bool empty() const { return _size == 0; }
   size_t size() const { return _size; }

   void pop_front() {
      if (empty()) return;
      erase(begin());
   }
   void pop_back() {
      if (empty()) return;
      iterator it = begin();
      for (int i = 0; i < _size - 1; ++i) ++it;
      erase(it);
   }

   bool erase(iterator pos) {
      if (!pos._node) return false;
      return erase(pos._node->_data);
   }

   bool erase(const T& x) {
      return eraseNode(_root, x);
   }

   iterator find(const T& x) const {
      BSTreeNode<T>* cur = _root;
      while (cur) {
         if (x < cur->_data) cur = cur->_left;
         else if (x > cur->_data) cur = cur->_right;
         else return iterator(cur);
      }
      return end();
   }

   void clear() {
      clearNode(_root);
      _root = nullptr;
      _size = 0;
   }

   void insert(const T& x) {
      insertNode(_root, x);
   }

private:
   BSTreeNode<T>* _root;
   size_t _size;

   void insertNode(BSTreeNode<T>*& node, const T& x) {
      if (!node) { node = new BSTreeNode<T>(x); ++_size; return; }
      if (x < node->_data) insertNode(node->_left, x);
      else insertNode(node->_right, x);
   }

   bool eraseNode(BSTreeNode<T>*& node, const T& x) {
      if (!node) return false;
      if (x < node->_data) return eraseNode(node->_left, x);
      else if (x > node->_data) return eraseNode(node->_right, x);
      else {
         if (!node->_left && !node->_right) {
            delete node; node = nullptr;
         } else if (!node->_left) {
            BSTreeNode<T>* tmp = node;
            node = node->_right;
            delete tmp;
         } else if (!node->_right) {
            BSTreeNode<T>* tmp = node;
            node = node->_left;
            delete tmp;
         } else {
            BSTreeNode<T>* succ = node->_right;
            while (succ->_left) succ = succ->_left;
            node->_data = succ->_data;
            eraseNode(node->_right, succ->_data);
         }
         --_size;
         return true;
      }
   }

   void clearNode(BSTreeNode<T>* node) {
      if (!node) return;
      clearNode(node->_left);
      clearNode(node->_right);
      delete node;
   }
};

template <class T>
BSTreeNode<T>* BSTree<T>::iterator::_root = nullptr;

#endif // BST_H
