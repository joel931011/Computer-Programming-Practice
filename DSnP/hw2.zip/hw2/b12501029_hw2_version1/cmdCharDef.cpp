/****************************************************************************
 FileName [ cmdCharDef.cpp ]
 PackageName [ cmd ]
 Synopsis [ Process keyboard inputs ]
****************************************************************************/
#include <iostream>
#include <iomanip>
#include <termios.h>
#include <stdlib.h>
#include <ctype.h>
#include <cassert>
#include "cmdCharDef.h"
using namespace std;

static struct termios stored_settings;

static void reset_keypress(void)
{
    tcsetattr(0, TCSANOW, &stored_settings);
}

static void set_keypress(void)
{
    struct termios new_settings;
    tcgetattr(0, &stored_settings);
    new_settings = stored_settings;
    new_settings.c_lflag &= ~ICANON;
    new_settings.c_lflag &= ~ECHO;
    new_settings.c_cc[VTIME] = 0;
    new_settings.c_cc[VMIN] = 1;
    tcsetattr(0, TCSANOW, &new_settings);
}

char mygetc(istream& istr)
{
    char ch;
    set_keypress();
    istr.unsetf(ios_base::skipws);
    istr >> ch;
    istr.setf(ios_base::skipws);
    reset_keypress();
    #ifdef TEST_ASC
    cout << left << setw(6) << int(ch);
    #endif
    return ch;
}

void mybeep()
{
    cout << char(BEEP_CHAR) << flush;
}

inline ParseChar returnCh(int ch)
{
    return ParseChar(ch);
}

#ifndef TA_KB_SETTING
ParseChar
getChar(istream& istr)
{
    char ch = mygetc(istr);
    if (istr.eof())
        return returnCh(INPUT_END_KEY);
    
    switch (ch) {
        case LINE_BEGIN_KEY:  // Ctrl-a
        case LINE_END_KEY:    // Ctrl-e
        case INPUT_END_KEY:   // Ctrl-d
        case TAB_KEY:         // tab('\t')
        case NEWLINE_KEY:     // enter('\n')
        case BACK_SPACE_KEY:  // backspace
            return returnCh(ch);
        
        case ESC_KEY: {
            char ch1 = mygetc(istr);
            if (ch1 == char(ARROW_KEY_INT)) { // ESC [ (91)
                char ch2 = mygetc(istr);
                if (ch2 >= 'A' && ch2 <= 'D') { // Arrow keys: A=65, B=66, C=67, D=68
                    return returnCh(int(ch2) + ARROW_KEY_FLAG);
                } else if (ch2 >= '1' && ch2 <= '6') { // Modifier keys: 1~ to 6~
                    char ch3 = mygetc(istr);
                    if (ch3 == MOD_KEY_DUMMY) { // ~ (126)
                        return returnCh(int(ch2) + MOD_KEY_FLAG);
                    }
                }
            } else if (ch1 == 79) { // ESC O
               char ch2 = mygetc(istr);
               if (ch2 == 'H') return returnCh(HOME_KEY); // ESC O H
               if (ch2 == 'F') return returnCh(END_KEY);  // ESC O F
            }
            mybeep();
            return returnCh(UNDEFINED_KEY); // No recursion
        }
        
        default:
            if (isprint(ch))
                return returnCh(ch);
            else
                return returnCh(UNDEFINED_KEY);
    }
}
#else // TA_KB_SETTING
// [Existing TA code unchanged]
#endif // TA_KB_SETTING