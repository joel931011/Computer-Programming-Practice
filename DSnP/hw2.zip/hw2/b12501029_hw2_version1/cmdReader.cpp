/****************************************************************************
  FileName     [ cmdReader.cpp ]
  PackageName  [ cmd ]
  Synopsis     [ Define command line reader member functions ]
  Author       [ Chung-Yang (Ric) Huang ]
  Copyright    [ Copyleft(c) 2007-present LaDs(III), GIEE, NTU, Taiwan ]
****************************************************************************/
#include <cassert>
#include <cstring>
#include "cmdParser.h"

using namespace std;

//----------------------------------------------------------------------
//    External functions
//----------------------------------------------------------------------
void mybeep();
char mygetc(istream&);
ParseChar getChar(istream&);

//----------------------------------------------------------------------
//    Member Function for class Parser
//----------------------------------------------------------------------
void
CmdParser::readCmd()
{
   if (_dofile.is_open()) {
      readCmdInt(_dofile);
      _dofile.close();
   }
   else
      readCmdInt(cin);
}

void
CmdParser::readCmdInt(istream& istr)
{
   resetBufAndPrintPrompt();

   while (1) {
      ParseChar pch = getChar(istr);
      if (pch == INPUT_END_KEY) break;
      switch (pch) {
         case LINE_BEGIN_KEY:
         case HOME_KEY:       moveBufPtr(_readBuf); break;
         case LINE_END_KEY:
         case END_KEY:        moveBufPtr(_readBufEnd); break;
         case BACK_SPACE_KEY: 
            if (moveBufPtr(_readBufPtr - 1)) {
               deleteChar();
            }
            break;
         case DELETE_KEY:     deleteChar(); break;
         case NEWLINE_KEY:    addHistory();
                              cout << char(NEWLINE_KEY);
                              resetBufAndPrintPrompt(); break;
         case ARROW_UP_KEY:   moveToHistory(_historyIdx - 1); break;
         case ARROW_DOWN_KEY: moveToHistory(_historyIdx + 1); break;
         case ARROW_RIGHT_KEY: moveBufPtr(_readBufPtr + 1); break;
         case ARROW_LEFT_KEY: moveBufPtr(_readBufPtr - 1); break;
         case PG_UP_KEY:      moveToHistory(_historyIdx - PG_OFFSET); break;
         case PG_DOWN_KEY:    moveToHistory(_historyIdx + PG_OFFSET); break;
         case TAB_KEY:        insertChar(' ', 4); break;
         case INSERT_KEY:     mybeep(); break; // Not supported
         case UNDEFINED_KEY:  mybeep(); break;
         default:  // Printable character
            // DEBUG: Log character
            // cout << "DEBUG: Inserting char " << char(pch) << endl;
            insertChar(char(pch), 1); break;
      }
      #ifdef TA_KB_SETTING
      taTestOnly();
      #endif
   }
}

bool
CmdParser::moveBufPtr(char* const ptr)
{
   if (ptr < _readBuf || ptr > _readBufEnd) {
      mybeep();
      return false;
   }

   int currentPos = _readBufPtr - _readBuf;
   int newPos = ptr - _readBuf;

   if (newPos < currentPos) {
      for (int i = 0; i < currentPos - newPos; ++i) {
         cout << '\b';
      }
   } else if (newPos > currentPos) {
      for (int i = currentPos; i < newPos; ++i) {
         cout << _readBuf[i];
      }
   }

   _readBufPtr = ptr;
   cout.flush();
   return true;
}

bool
CmdParser::deleteChar()
{
   if (_readBufPtr == _readBufEnd) {
      mybeep();
      return false;
   }

   for (char* p = _readBufPtr; p < _readBufEnd - 1; ++p) {
      *p = *(p + 1);
   }

   --_readBufEnd;
   *_readBufEnd = '\0';

   cout << _readBufPtr << ' ';
   for (char* p = _readBufPtr; p < _readBufEnd; ++p) {
      cout << '\b';
   }
   cout.flush();

   return true;
}

void
CmdParser::insertChar(char ch, int repeat)
{
   assert(repeat >= 1);

   // Assume _readBuf size is 4096 (adjust if cmdParser.h specifies otherwise)
   if (_readBufEnd + repeat >= _readBuf + 4096) {
      mybeep();
      return;
   }

   // Shift string right
   for (char* p = _readBufEnd; p >= _readBufPtr; --p) {
      *(p + repeat) = *p;
   }

   // Insert characters
   for (int i = 0; i < repeat; ++i) {
      *_readBufPtr = ch;
      ++_readBufPtr;
   }

   _readBufEnd += repeat;

   // Update screen
   cout << string(_readBufPtr - repeat, _readBufEnd);
   for (char* p = _readBufPtr; p < _readBufEnd; ++p) {
      cout << '\b';
   }
   cout.flush();
}

void
CmdParser::deleteLine()
{
   for (char* p = _readBufPtr; p > _readBuf; --p) {
      cout << '\b';
   }
   cout << string(_readBufEnd - _readBuf, ' ') << string(_readBufEnd - _readBuf, '\b');

   *_readBuf = '\0';
   _readBufPtr = _readBufEnd = _readBuf;
   cout.flush();
}

void
CmdParser::moveToHistory(int index)
{
   if (index == _historyIdx) {
      return;
   }

   if (index < _historyIdx) {
      if (_historyIdx == 0) {
         mybeep();
         return;
      }
      if (_historyIdx == (int)_history.size() && !_tempCmdStored) {
         _history.push_back(string(_readBuf));
         _tempCmdStored = true;
      }
      if (index < 0) {
         index = 0;
      }
   } else {
      if (_historyIdx == (int)_history.size()) {
         mybeep();
         return;
      }
      if (index >= (int)_history.size()) {
         index = _history.size() - 1;
      }
   }

   _historyIdx = index;
   retrieveHistory();
}

void
CmdParser::addHistory()
{
   string cmd(_readBuf);
   size_t start = cmd.find_first_not_of(' ');
   if (start == string::npos) {
      cmd.clear();
   } else {
      size_t end = cmd.find_last_not_of(' ');
      cmd = cmd.substr(start, end - start + 1);
   }

   if (!cmd.empty()) {
      if (_tempCmdStored) {
         _history.pop_back();
         _tempCmdStored = false;
      }
      _history.push_back(cmd);
   }

   _historyIdx = _history.size();
}