/****************************************************************************
  FileName     [ cmdCharDef.cpp ]
  PackageName  [ cmd ]
  Synopsis     [ Process keyboard inputs ]
  Author       [ Chung-Yang (Ric) Huang ]
  Copyright    [ Copyleft(c) 2007-present LaDs(III), GIEE, NTU, Taiwan ]
****************************************************************************/
#include "cmdCharDef.h"
#include <termios.h>
#include <cassert>
#include <cctype>
#include <cstdlib>
#include <iostream>

namespace
{
static struct termios storedSettings;

static void resetKeypress()
{
    tcsetattr(0, TCSANOW, &storedSettings);
}

static void setKeypress()
{
    struct termios newSettings;
    tcgetattr(0, &storedSettings);
    newSettings = storedSettings;
    newSettings.c_lflag &= (~ICANON);
    newSettings.c_lflag &= (~ECHO);
    newSettings.c_cc[VTIME] = 0;
    tcgetattr(0, &storedSettings);
    newSettings.c_cc[VMIN] = 1;
    tcsetattr(0, TCSANOW, &newSettings);
}
}
char mygetc(std::istream &istr)
{
    char character;
    setKeypress();
    istr.unsetf(std::ios_base::skipws);
    istr >> character;
    istr.setf(std::ios_base::skipws);
    resetKeypress();
#ifdef TEST_ASC
    std::cout << static_cast<int>(character);
#endif  // TEST_ASC
    return character;
}

void mybeep()
{
    std::cout << static_cast<char>(BEEP_CHAR);
}
inline ParseChar returnCh(int);
#ifndef TA_KB_SETTING
ParseChar getChar(std::istream &istr)
{
    const char character = mygetc(istr);
    if (istr.eof())
        return returnCh(INPUT_END_KEY);
    switch (character) {
    case LINE_BEGIN_KEY:  // Ctrl-a
    case LINE_END_KEY:    // Ctrl-e
    case INPUT_END_KEY:   // Ctrl-d
    case TAB_KEY:         // tab('\t') or Ctrl-i
    case NEWLINE_KEY:     // enter('\n') or ctrl-m
        return returnCh(character);
    case BACK_SPACE_KEY:
        return returnCh(character);
    case ESC_KEY: {
        char next = mygetc(istr);
        if (next == '[') {
            char final = mygetc(istr);
            switch (final) {
            case 'A': return returnCh(ARROW_UP_KEY);
            case 'B': return returnCh(ARROW_DOWN_KEY);
            case 'C': return returnCh(ARROW_RIGHT_KEY);
            case 'D': return returnCh(ARROW_LEFT_KEY);
            case '1': case '2': case '3': case '4': case '5': case '6': {
                char dummy = mygetc(istr); // expect '~'
                if (dummy != '~') return returnCh(UNDEFINED_KEY);
                switch (final) {
                case '1': return returnCh(HOME_KEY);
                case '2': return returnCh(INSERT_KEY);
                case '3': return returnCh(DELETE_KEY);
                case '4': return returnCh(END_KEY);
                case '5': return returnCh(PG_UP_KEY);
                case '6': return returnCh(PG_DOWN_KEY);
                }
            }
            }
            return returnCh(UNDEFINED_KEY);
        }
        return returnCh(UNDEFINED_KEY);
    }
    default:
        if (std::isprint(static_cast<unsigned char>(character)))
            return returnCh(character);
        else
            return returnCh(UNDEFINED_KEY);
    }

    return returnCh(UNDEFINED_KEY);
}
#else   // TA_KB_SETTING is defined
ParseChar getChar(std::istream &istr)
{
    const char character = mygetc(istr);

    if (istr.eof())
        return returnCh(INPUT_END_KEY);
    switch (character) {
    case LINE_BEGIN_KEY:  // Ctrl-a
    case LINE_END_KEY:    // Ctrl-e
    case INPUT_END_KEY:   // Ctrl-d
    case TAB_KEY:         // tab('\t') or Ctrl-i
    case NEWLINE_KEY:     // enter('\n') or ctrl-m
        return returnCh(character);
    case BACK_SPACE_KEY:
        return returnCh(character);
    case ESC_KEY: {
        const char combo = mygetc(istr);
        if (combo == static_cast<char>(MOD_KEY_INT)) {
            const char key = mygetc(istr);
            if ((key >= static_cast<char>(MOD_KEY_BEGIN)) &&
                (key <= static_cast<char>(MOD_KEY_END))) {
                if (mygetc(istr) == MOD_KEY_DUMMY)
                    return returnCh(static_cast<int>(key) + MOD_KEY_FLAG);
                else
                    return returnCh(UNDEFINED_KEY);
            }
            else if ((key >= static_cast<char>(ARROW_KEY_BEGIN)) &&
                     (key <= static_cast<char>(ARROW_KEY_END)))
                return returnCh(static_cast<int>(key) + ARROW_KEY_FLAG);
            else
                return returnCh(UNDEFINED_KEY);
        }
        else {
            mybeep();
            return getChar(istr);
        }
    }
    default:
        if (std::isprint(static_cast<unsigned char>(character)))
            return returnCh(character);
        else
            return returnCh(UNDEFINED_KEY);
    }

    return returnCh(UNDEFINED_KEY);
}
#endif  // TA_KB_SETTING

inline ParseChar returnCh(int character)
{
#ifndef MAKE_REF
    return ParseChar(character);
#else
    switch (ParseChar(character)) {
    case LINE_BEGIN_KEY:
        return ParseChar(TA_LINE_BEGIN_KEY);
    case LINE_END_KEY:
        return ParseChar(TA_LINE_END_KEY);
    case INPUT_END_KEY:
        return ParseChar(TA_INPUT_END_KEY);
    case TAB_KEY:
        return ParseChar(TA_TAB_KEY);
    case NEWLINE_KEY:
        return ParseChar(TA_NEWLINE_KEY);
    case ESC_KEY:
        return ParseChar(TA_ESC_KEY);
    case BACK_SPACE_KEY:
        return ParseChar(TA_BACK_SPACE_KEY);
    case ARROW_KEY_FLAG:
        return ParseChar(TA_ARROW_KEY_FLAG);
    case ARROW_KEY_INT:
        return ParseChar(TA_ARROW_KEY_INT);
    case ARROW_UP_KEY:
        return ParseChar(TA_ARROW_UP_KEY);
    case ARROW_DOWN_KEY:
        return ParseChar(TA_ARROW_DOWN_KEY);
    case ARROW_RIGHT_KEY:
        return ParseChar(TA_ARROW_RIGHT_KEY);
    case ARROW_LEFT_KEY:
        return ParseChar(TA_ARROW_LEFT_KEY);
    case MOD_KEY_FLAG:
        return ParseChar(TA_MOD_KEY_FLAG);
    case HOME_KEY:
        return ParseChar(TA_HOME_KEY);
    case INSERT_KEY:
        return ParseChar(TA_INSERT_KEY);
    case DELETE_KEY:
        return ParseChar(TA_DELETE_KEY);
    case END_KEY:
        return ParseChar(TA_END_KEY);
    case PG_UP_KEY:
        return ParseChar(TA_PG_UP_KEY);
    case PG_DOWN_KEY:
        return ParseChar(TA_PG_DOWN_KEY);
    case MOD_KEY_BEGIN:
        return ParseChar(TA_MOD_KEY_BEGIN);
    case MOD_KEY_END:
        return ParseChar(TA_MOD_KEY_END);
    case MOD_KEY_DUMMY:
        return ParseChar(TA_MOD_KEY_DUMMY);
    case UNDEFINED_KEY:
        return ParseChar(TA_UNDEFINED_KEY);
    case BEEP_CHAR:
        return ParseChar(TA_BEEP_CHAR);
    case BACK_SPACE_CHAR:
        return ParseChar(TA_BACK_SPACE_CHAR);
    case PARSE_CHAR_END:
        return ParseChar(TA_PARSE_CHAR_END);
    default:
        return ParseChar(TA_UNDEFINED_KEY);
    }
#endif
}