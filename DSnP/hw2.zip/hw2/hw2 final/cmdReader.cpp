/****************************************************************************
  FileName     [ cmdReader.cpp ]
  PackageName  [ cmd ]
  Synopsis     [ Define command line reader member functions ]
  Author       [ Chung-Yang (Ric) Huang ]
  Copyright    [ Copyleft(c) 2007-present LaDs(III), GIEE, NTU, Taiwan ]
****************************************************************************/
#include "cmdParser.h"
#include "cmdCharDef.h"

#include <cassert>
#include <cstring>
#include <iostream>

void mybeep();
char mygetc(std::istream &);
ParseChar getChar(std::istream &);

void CmdParser::readCmd()
{
    if (_dofile.is_open()) {
        readCmdInt(_dofile);
        _dofile.close();
    }
    else
        readCmdInt(std::cin);
}
void CmdParser::readCmdInt(std::istream &istr)
{
    resetBufAndPrintPrompt();
    while (true) {
        ParseChar pch = getChar(istr);
        if (pch == INPUT_END_KEY)
            break;
        switch (pch) {
        case LINE_BEGIN_KEY:
        case HOME_KEY:
            moveBufPtr(_readBuf);
            break;
        case LINE_END_KEY:
        case END_KEY:
            moveBufPtr(_readBufEnd);
            break;
        case BACK_SPACE_KEY:
            if (_readBufPtr != _readBuf) {
               moveBufPtr(_readBufPtr - 1);
               deleteChar();
            } else mybeep();
            break;
        case DELETE_KEY:
            deleteChar();
            break;
        case NEWLINE_KEY:
            addHistory();
            std::cout << static_cast<char>(NEWLINE_KEY);
            resetBufAndPrintPrompt();
            break;
        case ARROW_UP_KEY:
            moveToHistory(_historyIdx - 1);
            break;
        case ARROW_DOWN_KEY:
            moveToHistory(_historyIdx + 1);
            break;
        case ARROW_RIGHT_KEY: 
            moveBufPtr(_readBufPtr + 1);
            break;
        case ARROW_LEFT_KEY:
            moveBufPtr(_readBufPtr - 1);
            break;
        case PG_UP_KEY:
            moveToHistory(_historyIdx - PG_OFFSET);
            break;
        case PG_DOWN_KEY:
            moveToHistory(_historyIdx + PG_OFFSET);
            break;
        case TAB_KEY:{
            int n = TAB_POSITION - ((_readBufPtr - _readBuf) % TAB_POSITION);
            insertChar(' ', n);
            break;}
        case INSERT_KEY:
        case UNDEFINED_KEY:
            mybeep();
            break;
        default:  // printable character
            insertChar(static_cast<char>(pch));
            break;
        }
#ifdef TA_KB_SETTING
        taTestOnly();
#endif
    }
}
bool CmdParser::moveBufPtr(char *const ptr)
{
   if (ptr < _readBuf || ptr > _readBufEnd) {
        mybeep();
        return false;
    }
    while (_readBufPtr < ptr) {
        std::cout << *_readBufPtr;
        ++_readBufPtr;
    }
    while (_readBufPtr > ptr) {
        std::cout << '\b';
        --_readBufPtr;
    }
    return true;
}
bool CmdParser::deleteChar()
{
   if (_readBufPtr == _readBufEnd) {
        mybeep();
        return false;
    }
    std::memmove(_readBufPtr, _readBufPtr + 1, _readBufEnd - _readBufPtr);
    --_readBufEnd;
    *_readBufEnd = 0;
    std::cout << _readBufPtr << ' ';
    for (char *p = _readBufPtr; p <= _readBufEnd; ++p)
        std::cout << '\b';    return true;
}
void CmdParser::insertChar(char character, int repeat)
{
    assert(repeat >= 1);
    std::memmove(_readBufPtr + repeat, _readBufPtr, _readBufEnd - _readBufPtr);
    for (int i = 0; i < repeat; ++i)
        _readBufPtr[i] = character;
    _readBufEnd += repeat;
    *_readBufEnd = 0;
    std::cout << _readBufPtr;
    _readBufPtr += repeat;
    for (char *p = _readBufPtr; p < _readBufEnd; ++p)
        std::cout << '\b';
}
void CmdParser::deleteLine()
{
   moveBufPtr(_readBufEnd);
   while (_readBufPtr > _readBuf) {
        std::cout << '\b' << ' ' << '\b';
        --_readBufPtr;
    }
    _readBufEnd = _readBuf;
    *_readBufEnd = 0;
}
void CmdParser::moveToHistory(int index)
{
   if (index < _historyIdx) { // move up
        if (_historyIdx == 0) {
            mybeep();
            return;
        }
        if (!_tempCmdStored) {
            _history.push_back(std::string(_readBuf));
            _tempCmdStored = true;
        }
        if (index < 0) index = 0;
    } else if (index > _historyIdx) { // move down
        if (_historyIdx == static_cast<int>(_history.size())) {
            mybeep();
            return;
        }
        if (index >= static_cast<int>(_history.size()))
            index = _history.size() - 1;
    } else return;

    _historyIdx = index;
    retrieveHistory();
}
void CmdParser::addHistory()
{
   std::string str(_readBuf);
    size_t start = str.find_first_not_of(' ');
    size_t end = str.find_last_not_of(' ');
    if (start != std::string::npos && end != std::string::npos)
        str = str.substr(start, end - start + 1);
    else
        str = "";
    if (!str.empty()) {
        if (_tempCmdStored) {
            _history.back() = str;
            _tempCmdStored = false;
        } else {
            _history.push_back(str);
        }
    }
    else if (_tempCmdStored) {
        _history.pop_back();
        _tempCmdStored = false;
    }
    _historyIdx = _history.size();
}
void CmdParser::retrieveHistory()
{
   deleteLine();
    if (_historyIdx < static_cast<int>(_history.size())) {
        strcpy(_readBuf, _history[_historyIdx].c_str());
        _readBufEnd = _readBuf + _history[_historyIdx].size();
        *_readBufEnd = 0;
        std::cout << _readBuf;
    }
    else {
        *_readBuf = 0;
        _readBufEnd = _readBuf;
    }
    _readBufPtr = _readBufEnd;
}