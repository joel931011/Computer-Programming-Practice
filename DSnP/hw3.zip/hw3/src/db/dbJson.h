#ifndef DB_JSON_H
#define DB_JSON_H

#include <vector>
#include <string>
#include <unordered_set>
#include <iostream>

using namespace std;

struct DBSortKey;
struct DBSortValue;

class DBJsonElem
{
public:
   DBJsonElem() {}
   DBJsonElem(const string& k, int v): _key(k), _value(v) {}

   const string& key() const { return _key; }
   string& key() { return _key; }
   const int& value() const { return _value; }
   int& value() { return _value; }

   friend ostream& operator << (ostream&, const DBJsonElem&);

private:
   string  _key;
   int     _value;
};

class DBJson
{
public:
   DBJson() : _read(false) {}

   bool add(const DBJsonElem&);
   float ave() const;
   int max(size_t&) const;
   int min(size_t&) const;
   void sort(const DBSortKey&);
   void sort(const DBSortValue&);
   int sum() const;

   void reset();
   size_t size() const { return _obj.size(); }
   bool empty() const { return _obj.empty(); }

   DBJsonElem& operator [] (size_t i) { return _obj[i]; }
   const DBJsonElem& operator [] (size_t i) const { return _obj[i]; }

   bool operator !() const { return !_read; }
   operator void* () const { return _read ? (void*)this : nullptr; }

   friend istream& operator >> (istream&, DBJson&);
   friend ostream& operator << (ostream&, const DBJson&);

private:
   vector<DBJsonElem> _obj;
   bool _read;
};

struct DBSortKey
{
   bool operator() (const DBJsonElem& m1, const DBJsonElem& m2) const {
      return (m1.key() < m2.key());
   }
};

struct DBSortValue
{
   bool operator() (const DBJsonElem& m1, const DBJsonElem& m2) const {
      return (m1.value() < m2.value());
   }
};

#endif // DB_JSON_H
