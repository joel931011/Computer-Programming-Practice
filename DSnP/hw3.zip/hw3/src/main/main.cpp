#include <cstdlib>
#include <iostream>
#include <fstream>
#include "util.h"
#include "cmdParser.h"

using namespace std;

//----------------------------------------------------------------------
//    Global cmd Manager
//----------------------------------------------------------------------
CmdParser* cmdMgr = new CmdParser("mydb> ");

extern bool initCommonCmd();
extern bool initDbCmd();

static void
usage()
{
   // Updated to match your current project name
   cout << "Usage: mydb [ -File < doFile > ]" << endl;
}

static void
myexit()
{
   usage();
   exit(-1);
}

int
main(int argc, char** argv)
{
   // Check for command line arguments
   if (argc == 3) {  // mydb -File <doFile>
      if (myStrNCmp("-File", argv[1], 2) == 0) {
         if (!cmdMgr->openDofile(argv[2])) {
            // Error message already handled by openDofile usually, 
            // but we keep this for safety.
            myexit();
         }
      }
      else {
         cerr << "Error: unknown argument \"" << argv[1] << "\"!!\n";
         myexit();
      }
   }
   else if (argc != 1) {
      cerr << "Error: illegal number of argument (" << argc << ")!!\n";
      myexit();
   }

   // Initialize commands
   // This is where it was failing. Make sure dbCmd.cpp has the correct 
   // regCmd calls!
   if (!initCommonCmd() || !initDbCmd())
      return 1;

   CmdExecStatus status = CMD_EXEC_DONE;
   while (status != CMD_EXEC_QUIT) {
      // This is the interactive loop
      status = cmdMgr->execOneCmd();
   }

   return 0;
}